APLIKASI ORIENT (PWA) - PETUNJUK PEMASANGAN
==========================================

Isi folder ini adalah "pembungkus" aplikasi ORIENT agar bisa di-install di HP (Android/iOS) dan
komputer (Windows/Mac). Aplikasinya sendiri tetap Google Apps Script yang sudah ada: semua data
tetap tersimpan otomatis ke Google Sheets seperti biasa.

File:
  index.html              halaman aplikasi (layar pembuka + membuka Web App Apps Script layar penuh)
  manifest.webmanifest    identitas aplikasi: nama ORIENT, ikon, warna
  sw.js                   service worker (syarat aplikasi dapat dipasang)
  icon-192.png, icon-512.png, icon-maskable-512.png, apple-touch-icon.png, favicon-64.png   logo Orient

LANGKAH 1 - Isi URL Web App
  Buka index.html, ganti baris:
    const GAS_URL = 'https://script.google.com/macros/s/GANTI_DENGAN_ID_DEPLOYMENT/exec';
  dengan URL Web App Apps Script Anda (Deploy > Manage deployments > salin "Web app URL", berakhiran /exec).

LANGKAH 2 - Unggah ke hosting HTTPS gratis (contoh GitHub Pages)
  1. Buat akun / masuk ke github.com, klik New repository, beri nama mis. "orient", pilih Public, Create.
  2. Klik "uploading an existing file", unggah SEMUA file di folder ini (bukan foldernya), lalu Commit.
  3. Settings > Pages > Source: "Deploy from a branch" > Branch: main / (root) > Save.
  4. Tunggu 1-2 menit. Alamat aplikasi: https://<nama-akun>.github.io/orient/

LANGKAH 3 - Ikon di tab browser (opsional)
  Di code.gs isi CONFIG.APP_ICON_URL dengan https://<nama-akun>.github.io/orient/icon-192.png
  lalu Deploy > Manage deployments > Edit > New version > Deploy.

LANGKAH 4 - Pasang di perangkat (buka alamat GitHub Pages di atas)
  Android (Chrome)      : tombol "Pasang Aplikasi ORIENT" di kanan bawah, atau menu titik tiga > Instal aplikasi.
  iPhone/iPad (Safari)  : tombol Bagikan > Tambah ke Layar Utama.
  Windows/Mac (Chrome/Edge): ikon "Instal" di ujung kanan kolom alamat, atau tombol "Pasang Aplikasi ORIENT".

Catatan:
  - Setiap ada perubahan code.gs / index.html di Apps Script, aplikasi yang terpasang ikut berubah
    otomatis (cukup Deploy versi baru seperti biasa). Folder ini tidak perlu diunggah ulang.
  - Bila URL /exec berubah (deploy baru, bukan "Edit"), ubah GAS_URL di index.html lalu unggah ulang.
