/* Service worker aplikasi ORIENT.
 * Hanya menyimpan "cangkang" aplikasi (halaman pembuka, ikon, manifest) agar aplikasi bisa dipasang dan
 * tetap terbuka saat sinyal lemah. Data service TIDAK disimpan di sini: semua data tetap dikirim langsung
 * ke Google Apps Script -> Google Sheets seperti biasa. */
const CACHE = 'orient-shell-v1';
const SHELL = ['./', './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png', './icon-maskable-512.png', './apple-touch-icon.png', './favicon-64.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return; // Apps Script & Google: selalu langsung ke internet
  // jaringan dulu (agar pembaruan langsung terpakai), cadangan dari cache saat offline
  e.respondWith(
    fetch(req).then(res => { const copy = res.clone(); caches.open(CACHE).then(c => c.put(req, copy)); return res; })
      .catch(() => caches.match(req).then(r => r || caches.match('./index.html')))
  );
});
